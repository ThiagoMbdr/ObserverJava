package Observer;

import java.util.Date;
import java.util.Observable;
import java.util.Observer;

public class Entregador implements Observer{

		Observable solicita��o;
		 
		String novaSolicitacao;
		String empresaSolicitante;
		String quantidadeEntregadores;
		String diasDaSemana;
		
		public Entregador(Observable Solicita��o) {
			this.solicita��o = Solicita��o;
			Solicita��o.addObserver(this);
			
		}

		public void update(Observable solicita��oSubject, Object arg) {
			
			if (solicita��oSubject instanceof Solicita��o) {
	            Solicita��o solicitacao = (Solicita��o) solicita��oSubject;
	            novaSolicitacao = solicitacao.getidSolicita��o();
	            empresaSolicitante = solicitacao.getEmpresa();
	           // diasDaSemana = solicitacao.getdiasDaSemana();
	            quantidadeEntregadores = solicitacao.getquantidadeEntregadores();
	            System.out.println("Aten��o, nova notifica��o para Entrega.\n" +
	            "Esta � uma Solicita��o de: " + novaSolicitacao + "\nEmpresa: " + empresaSolicitante + "\nQuantidade de Entregadores: " + quantidadeEntregadores + "\nDias da Semanada: " + diasDaSemana);
	        }
			
		}
}
