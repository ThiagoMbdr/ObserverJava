package Observer;

import java.util.Date;
import java.util.Observable;

public class Solicita��o extends Observable {

	public String idSolicita��o;
	private String empresaSolicitante;
	private String quantidadeEntregadores;
	//private String diasDaSemana;

	public void setNovaSolicita��o(String solicita��o, String empresa, String quantentregadores) {
		this.idSolicita��o = solicita��o;
		this.empresaSolicitante = empresa;
		this.quantidadeEntregadores = quantentregadores;
		//this.diasDaSemana = diasDaSemana;

		setChanged();
		notifyObservers();
	}

	public String getidSolicita��o() {
		return this.idSolicita��o;
	}

	public String getEmpresa() {
		return this.empresaSolicitante;
	}

	public String getquantidadeEntregadores() {
		return this.quantidadeEntregadores;
	}

	//public String getdiasDaSemana() {
	//	return this.getdiasDaSemana();
	//}

}
