package Principal;

import java.util.Date;

import Observer.Entregador;
import Observer.Solicita��o;

public class Principal {
	public static void main(String[] args) {

		String novaSolicitacao = "Entrega Impressora pizza gigantesca";;
		String empresaSolicitante = "NerisPizzaria";
		String quantidadeEntregadores = "2";
		//String diasDaSemana = "Segunda e Quarta";
		
        Solicita��o solicitacao = new Solicita��o();    
        Entregador entregador = new Entregador(solicitacao);
         
		solicitacao.setNovaSolicita��o(novaSolicitacao, empresaSolicitante, quantidadeEntregadores);
    }
 

}
